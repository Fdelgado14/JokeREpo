import UIKit

var one = "What do you call a pig that does karate?"
var two = "A pork chop"

print(one + "\n")
print(two)
